//
//  ViewController.swift
//  MathHub Pro
//
//  Created by Manish Bhanushali on 26/11/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var btn3: UIButton!
    
    @IBOutlet weak var btn1: UIButton!
    
    @IBOutlet weak var btn2: UIButton!
    
    
    @IBOutlet weak var btn4: UIButton!
    
    @IBOutlet weak var btn5: UIButton!
    
    @IBOutlet weak var btn6: UIButton!
    
    
    @IBOutlet weak var btn7: UIButton!
    
    @IBOutlet weak var btn8: UIButton!
    
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        btn1.layer.cornerRadius = 5
        btn2.layer.cornerRadius = 5
        btn3.layer.cornerRadius = 5
        btn4.layer.cornerRadius = 5
        btn5.layer.cornerRadius = 5
        btn6.layer.cornerRadius = 5
        btn7.layer.cornerRadius = 5
        btn8.layer.cornerRadius = 5
        
        
        
        
        
        
        // Do any additional setup after loading the view.
    }


}

